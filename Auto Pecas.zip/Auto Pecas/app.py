from flask import Flask, render_template, request, redirect, url_for, jsonify
from services import consulta_por_placa, chat_ia
from catalogo_local import CATALOGO, GRUPOS_VALIDOS

app = Flask(__name__)
app.secret_key = "autopecas2025"


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        tipo = request.form.get("busca_tipo")
        if tipo == "placa":
            return redirect(url_for("veiculo_por_placa",
                                    placa=request.form.get("placa", "").strip()))
        elif tipo == "manual":
            return redirect(url_for("veiculo_manual",
                                    modelo=request.form.get("modelo", "").strip(),
                                    ano=request.form.get("ano", "").strip(),
                                    motor=request.form.get("motor", "").strip(),
                                    bloco=request.form.get("bloco", "").strip()))
    return render_template("index.html")


@app.route("/chat")
def chat():
    return render_template("chat.html")


@app.route("/api/chat", methods=["POST"])
def api_chat():
    data      = request.get_json()
    mensagem  = data.get("mensagem", "")
    historico = data.get("historico", [])
    contexto  = data.get("contexto_veiculo", "")
    resposta  = chat_ia(mensagem, historico, contexto)
    return jsonify({"resposta": resposta})


@app.route("/veiculo/placa/<placa>")
def veiculo_por_placa(placa):
    veiculo = consulta_por_placa(placa)
    if not veiculo:
        return render_template("resultado_veiculo.html", veiculo=None,
                               erro="Placa nao encontrada. Verifique o token da API em services.py")
    return render_template("resultado_veiculo.html", veiculo=veiculo, erro=None)


@app.route("/veiculo/manual")
def veiculo_manual():
    veiculo = {
        "placa":      None,
        "marca":      None,
        "modelo":     request.args.get("modelo"),
        "versao":     request.args.get("bloco"),
        "ano":        request.args.get("ano"),
        "motor":      request.args.get("motor"),
        "combustivel":None,
    }
    return render_template("resultado_veiculo.html", veiculo=veiculo, erro=None)


@app.route("/pecas")
def pecas():
    grupo = request.args.get("grupo", "motor")
    if grupo not in GRUPOS_VALIDOS:
        grupo = "motor"
    veiculo = {
        "placa":  request.args.get("placa"),
        "marca":  request.args.get("marca"),
        "modelo": request.args.get("modelo"),
        "ano":    request.args.get("ano"),
        "motor":  request.args.get("motor"),
    }
    lista = CATALOGO.get(grupo, [])
    return render_template("pecas.html", grupo=grupo, grupos=GRUPOS_VALIDOS,
                           pecas=lista, veiculo=veiculo)


if __name__ == "__main__":
    app.run(debug=True)
