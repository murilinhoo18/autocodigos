import requests
import os
OPENAI_API_KEY  = os.environ.get("OPENAI_API_KEY", "")
API_PLACA_TOKEN = os.environ.get("API_PLACA_TOKEN", "")
from openai import OpenAI

# =====================
# CONFIG API PLACA
# =====================
# Crie conta em: https://placafipe.com.br ou https://apiplacas.com.br
# =====================
# CONFIG OPENAI
# =====================
# Crie chave em: https://platform.openai.com/api-keys

client = OpenAI(api_key=OPENAI_API_KEY)

SYSTEM_PROMPT = """Voce e um assistente tecnico especialista em autopecas do mercado brasileiro.
Quando informarem um veiculo (marca, modelo, ano e motor), forneca as pecas corretas com:
- Descricao da peca
- Marca recomendada
- Codigo do fabricante sempre que possivel (ex: NGK BKR5E, Wega WO-219, Bosch F026407072)

MARCAS PRIORITARIAS:
- Filtros: Wega / Tecfil
- Velas: NGK
- Sonda lambda: NGK / Delphi / MTE
- Bobinas: NGK / Magneti Marelli / Delphi / Hella / Bosch
- Cabos de vela: NGK / Delphi
- Correias: Contitech / Dayco
- Tensores / Polias: Ranalle
- Retentores / Juntas: Sabo / Elring / Taranto / Bastos
- Amortecedores: Cofap / Nakata
- Kit batente / buchas / bieletas: WS FLEX / Sampel / Nakata / Axios
- Molas: Cofap / Fabrini / Master Molas / Cindumel
- Pastilhas: SYL / Cobreq / Jurid
- Discos: MDS / Fremax / Hipper Freios
- Rolamentos / Cubos: IRB / SKF / MDS / Nakata / Hipper Freios
- Cilindros: Starke / Ate / Controil / TRW
- Embreagem: Luk / Elper
- Homocinetica / Tulipa: Perfect / Devigili / Vetor
- Bombas: Schadek / GMB / Takao / Indisa
- Suspensao (bandeja): Perfect
- Pivo / Terminal: Driveway / Yiming
- Bieleta: Delphi / Nakata / WS FLEX
- Termostato: Wahler / MTE
- Radiador: IRB
- Mangueiras: Jahu / MF / MG
- Sensor nivel: TSA / DS
- Pistao / Aneis / Bronzinas: Takao / KS / Metal Leve
- Parafuso cabecote: Elring / Takao / Taranto
- Barra axial: Bortec

NAO mencione: forro de porta, tapete, bancos, parabrisa, lanterna, farol, lataria, itens esteticos.
Responda sempre em portugues do Brasil, de forma tecnica e direta.
Quando souber o codigo da peca, coloque entre parenteses."""


def consulta_por_placa(placa: str):
    placa = placa.replace("-", "").upper()
    url = API_PLACA_URL.format(placa=placa, token=API_PLACA_TOKEN)
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code != 200:
            return None
        data = resp.json()
        return {
            "placa":       placa,
            "marca":       data.get("marca") or data.get("MARCA"),
            "modelo":      data.get("modelo") or data.get("MODELO"),
            "versao":      data.get("versao") or data.get("VERSAO"),
            "ano":         data.get("ano") or data.get("anoModelo") or data.get("ano_modelo"),
            "motor":       (data.get("extra") or {}).get("cilindradas"),
            "combustivel": data.get("combustivel"),
        }
    except Exception:
        return None


def chat_ia(mensagem: str, historico: list = None, contexto_veiculo: str = "") -> str:
    if historico is None:
        historico = []

    system = SYSTEM_PROMPT
    if contexto_veiculo and contexto_veiculo.strip():
        system += f"\n\nVeiculo em atendimento: {contexto_veiculo}"

    messages = [{"role": "system", "content": system}]
    for h in historico[-10:]:
        messages.append(h)
    messages.append({"role": "user", "content": mensagem})

    try:
        resp = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=0.2,
            max_tokens=1200,
        )
        return resp.choices[0].message.content
    except Exception as e:
        return f"Erro na IA: {str(e)}\n\nVerifique se a chave OpenAI esta correta em services.py"
