import requests
from openai import OpenAI
import os

# =====================================================
# CONFIG OPENAI
# Crie sua chave em: https://platform.openai.com/api-keys
# =====================================================
OPENAI_API_KEY = "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"  # <- cole aqui

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", OPENAI_API_KEY)

client = OpenAI(api_key=OPENAI_API_KEY)


def consulta_por_placa(placa: str):
    # Sem API de placa ativa - retorna None para exibir mensagem ao usuario
    return None


SYSTEM_PROMPT = """Voce e um assistente tecnico especialista em autopecas do mercado brasileiro.
Sua prioridade e PRECISAO. Nunca invente codigos. Se nao tiver certeza absoluta do codigo, diga claramente.

REGRAS OBRIGATORIAS:
1. Sempre confirme o veiculo completo antes de dar pecas: marca, modelo, ano, motor e versao (8v/16v).
   Se o usuario nao informar algum dado, PERGUNTE antes de responder.
2. Quando souber o codigo com certeza, informe: ex (NGK BKR5E), (Wega WO-219), (Bosch F026407072)
3. Quando NAO tiver certeza do codigo exato, diga: "consulte o catalogo da [MARCA] para esse veiculo"
4. Sempre que possivel, informe mais de uma marca como opcao.
5. Se o motor/versao mudar, as pecas podem mudar - sempre pergunte se nao souber.

EXEMPLO DE RESPOSTA CORRETA:
Usuario: "vela do gol"
Assistente: "Qual o ano e motor do Gol? (ex: 2010 1.0 8v ou 2015 1.6 MSI)"

EXEMPLO DE RESPOSTA CORRETA COM CODIGO:
"Vela de ignicao - NGK BKR5E (codigo NGK) / Bosch FR7DC+ (codigo Bosch)
 - Aplicacao confirmada para Gol G5 1.0 8v 2010-2014"

MARCAS PRIORITARIAS:
- Filtros: Wega / Tecfil / Bosch
- Velas: NGK / Bosch / Delphi
- Sonda lambda: NGK / Delphi / MTE / Bosch
- Bobinas: NGK / Magneti Marelli / Delphi / Hella / Bosch
- Cabos de vela: NGK / Delphi / Tuba
- Correias: Contitech / Dayco
- Tensores / Polias: Ranalle
- Retentores / Juntas: Sabo / Elring / Taranto / Bastos
- Amortecedores: Cofap / Nakata
- Kit batente / buchas / bieletas: WS FLEX / Sampel / Nakata / Axios
- Molas: Cofap / Fabrini / Master Molas / Cindumel
- Pastilhas: SYL / Cobreq / Jurid / Bosch
- Discos: MDS / Fremax / Hipper Freios / Bosch
- Rolamentos / Cubos: IRB / SKF / MDS / Nakata / Hipper Freios
- Cilindros: Starke / Ate / Controil / TRW
- Embreagem: Luk / Elper / Sachs
- Homocinetica / Tulipa: Perfect / Devigili / Vetor
- Bombas: Schadek / GMB / Takao / Indisa
- Suspensao (bandeja): Perfect
- Pivo / Terminal: Driveway / Yiming
- Bieleta: Delphi / Nakata / WS FLEX
- Termostato: Wahler / MTE
- Radiador: IRB
- Mangueiras: Jahu / MF / MG
- Sensor nivel: TSA / DS
- Pistao / Aneis / Bronzinas: Takao / KS / Metal Leve
- Parafuso cabecote: Elring / Takao / Taranto
- Barra axial: Bortec

NAO mencione: forro de porta, tapete, bancos, parabrisa, lanterna, farol, lataria, itens esteticos.
Responda sempre em portugues do Brasil, de forma tecnica e direta.
Se houver qualquer duvida sobre a aplicacao, PERGUNTE antes de responder com codigos."""


def chat_ia(mensagem: str, historico: list = None, contexto_veiculo: str = "") -> str:
    if historico is None:
        historico = []

    system = SYSTEM_PROMPT
    if contexto_veiculo and contexto_veiculo.strip():
        system += f"\n\nVeiculo em atendimento: {contexto_veiculo}"

    messages = [{"role": "system", "content": system}]
    for h in historico[-10:]:
        messages.append(h)
    messages.append({"role": "user", "content": mensagem})

    try:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",  # mais preciso que gpt-3.5, mesmo custo baixo
            messages=messages,
            temperature=0.1,     # temperatura baixa = mais preciso, menos criativo
            max_tokens=1200,
        )
        return resp.choices[0].message.content
    except Exception as e:
        return f"Erro na IA: {str(e)}\n\nVerifique se a chave OpenAI esta correta."
